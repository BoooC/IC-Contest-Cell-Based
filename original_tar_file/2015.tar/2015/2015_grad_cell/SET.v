module SET ( 
	input 				clk, 
	input 				rst,
	input 				en,
	input 		[23:0] 	central,
	input 		[11:0] 	radius,
	input 		[1:0] 	mode,
	output  			busy,
	output reg			valid,
	output reg	[7:0]	candidate
);

endmodule
