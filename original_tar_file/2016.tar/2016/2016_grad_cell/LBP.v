module LBP(
	input   		  	clk,
	input   		 	reset,
	output reg 	[13:0] 	gray_addr,
	output 	        	gray_req,
	input   	 	  	gray_ready,
	input   	[7:0] 	gray_data,
	output  	[13:0] 	lbp_addr,
	output  	  	  	lbp_valid,
	output  	[7:0]  	lbp_data,
	output  	  	  	finish
);

endmodule
