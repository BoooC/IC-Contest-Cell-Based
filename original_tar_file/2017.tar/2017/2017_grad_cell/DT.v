module DT(
	input 			clk, 
	input			reset,
	output			done,

	// Read from ROM
	output			sti_rd,
	output	reg 	[9:0]	sti_addr,  // 0 ~ 1023
	input			[15:0]	sti_di,

	// Write / READ RAM 
	output			res_wr,
	output			res_rd,
	output	reg 	[13:0]	res_addr,
	output		 	[7:0]	res_do,
	input			[7:0]	res_di
);


endmodule
