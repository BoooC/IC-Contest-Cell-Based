module LCD_CTRL (
	input 				clk,
	input 				reset,
	input 		[3:0] 	cmd,
	input 				cmd_valid,
	input 		[7:0] 	IROM_Q,
	output 		 		IROM_rd,
	output		[5:0]	IROM_A,
	output				IRAM_valid,
	output		[7:0] 	IRAM_D,
	output		[5:0] 	IRAM_A,
	output	reg			busy,
	output				done
);


endmodule
