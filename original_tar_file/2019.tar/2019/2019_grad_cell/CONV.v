module  CONV(
	input						clk, 
	input						reset, 
	output	reg					busy,	
	input						ready,				
	output 	reg			[11:0]	iaddr,
	input 		signed	[19:0]	idata,	
	output 	 		 			cwr,
	output 	reg			[11:0] 	caddr_wr,
	output 		signed	[19:0] 	cdata_wr,	
	output 				 		crd,
	output 				[11:0]	caddr_rd,
	input		signed	[19:0]	cdata_rd,
	output 	reg			[2:0] 	csel
);


endmodule
