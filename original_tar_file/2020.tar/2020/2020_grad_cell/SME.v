module SME (
	input				clk,
	input				reset,
	input		[7:0] 	chardata,
	input 				isstring,
	input 				ispattern,
	output 	reg 		match,
	output	reg	[4:0] 	match_index,
	output	reg 		valid
);


endmodule
