module geofence (
	input 			clk,
	input			reset,
	input	[9:0] 	X,
	input	[9:0] 	Y,
	output 			valid,
	output 	reg		is_inside
);


endmodule
